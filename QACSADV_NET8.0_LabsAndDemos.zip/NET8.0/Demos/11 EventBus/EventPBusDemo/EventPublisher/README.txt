﻿Before running either of the 2 projects you need to start up RabbitMQ in a docker container. 
You must specify the port mapping to be 5672:5672 by running the following command from PowerShell 
or the command line:

docker run -d --name rabbitmq -p 5672:5672 -p 15672:15672 rabbitmq:latest