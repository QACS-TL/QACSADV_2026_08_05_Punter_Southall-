﻿using Microsoft.AspNetCore.Mvc;
using ADONETDBAccess.Models;

namespace ADONETDBAccess.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class ProductsController : ControllerBase
    {
        private readonly NorthwindContext _context;

        public ProductsController(NorthwindContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
        }

        [HttpGet(Name = "GetProducts")]
        public IEnumerable<Product> Index()
        {
            List<Product> products = _context.Products.ToList();
            return products;
        }
    }
}
