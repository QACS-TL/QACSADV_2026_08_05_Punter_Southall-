﻿namespace ParallelFor
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            pictureBox1 = new PictureBox();
            pictureBox2 = new PictureBox();
            StartRaceButton = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.bluecar;
            pictureBox1.Location = new Point(28, 262);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(218, 89);
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            pictureBox1.Tag = "Blue";
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.greencar;
            pictureBox2.Location = new Point(28, 390);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(218, 89);
            pictureBox2.TabIndex = 1;
            pictureBox2.TabStop = false;
            pictureBox2.Tag = "Green";
            // 
            // StartRaceButton
            // 
            StartRaceButton.Location = new Point(12, 534);
            StartRaceButton.Name = "StartRaceButton";
            StartRaceButton.Size = new Size(103, 39);
            StartRaceButton.TabIndex = 2;
            StartRaceButton.Text = "Start Race";
            StartRaceButton.UseVisualStyleBackColor = true;
            StartRaceButton.Click += StartRaceButton_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 595);
            Controls.Add(StartRaceButton);
            Controls.Add(pictureBox2);
            Controls.Add(pictureBox1);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private PictureBox pictureBox1;
        private PictureBox pictureBox2;
        private Button StartRaceButton;
    }
}
