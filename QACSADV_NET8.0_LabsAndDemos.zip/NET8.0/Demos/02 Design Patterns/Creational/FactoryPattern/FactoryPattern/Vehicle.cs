﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FactoryPattern
{
    // Given no 'concrete' functionality this could have been an interface but 
    // given genuine vehicles exhibit a lot of common functionality in a
    // more sophisticated 'real world' example a class or abstract class
    //  may well be more appropriate
    // 'Product' Abstract Class
    public abstract class Vehicle
    {
        public abstract void Drive();
    }
}
