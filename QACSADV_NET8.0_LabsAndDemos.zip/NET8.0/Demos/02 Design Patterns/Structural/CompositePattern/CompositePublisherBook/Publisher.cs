﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CompositePublisherBook
{
    internal class Publisher : Text
    {
        private List<Text> _children = new List<Text>();

        public Publisher(string name, string blurb) : base(name, blurb) { }
        public override void Add(Text component) => _children.Add(component);
        public override void Remove(Text component) => _children.Remove(component);
        public override void Display(int depth)
        {
            Console.WriteLine(new String('-', depth) + Name);
            _children.ForEach(comp => comp.Display(depth + 2));
        }
    }
}

