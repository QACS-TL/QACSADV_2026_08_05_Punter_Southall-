﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace CompositePublisherBook
{
    internal class Book:Text
    {
        public Book(string name, string blurb) : base(name, blurb) { }
        public override void Add(Text component) => Console.WriteLine($"{component.Name} added to {this.Name}");
        public override void Remove(Text component) => Console.WriteLine($"{component.Name} removed from {this.Name}");
        public override void Display(int depth) => Console.WriteLine(new String('-', depth) + Name);
    }
}

