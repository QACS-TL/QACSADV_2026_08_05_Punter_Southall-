﻿using System;

namespace GarbageCollectionDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Application started.\n");

            UseExpensiveResource();

            Console.WriteLine("\nForcing garbage collection...");
            GC.Collect();
            GC.WaitForPendingFinalizers();

            Console.WriteLine("\nApplication ending.");
        }

        static void UseExpensiveResource()
        {
            Console.WriteLine("Creating expensive resource...");
            using (var resource = new ExpensiveResource())
            {
                resource.Use();
            } // Dispose is called here automatically

            //var resource = new ExpensiveResource();
            //resource.Use();

            Console.WriteLine("Expensive resource disposed.\n");
        }
    }


}
